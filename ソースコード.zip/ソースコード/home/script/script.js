$(function(){
    $('.todoufuken p').on('click', function(){
        var getClass = $(this).attr('class');
        alert(getClass);
    });
});