
    // googlemapScript
    var map;
    var locationFlg = 0; //位置情報 有効/無効 1/0

    function dispLatLng(){//緯度経度表示
        var latlng = map.getCenter();
        document.getElementById("lat").value = latlng.lat();
        document.getElementById("lng").value = latlng.lng();
        
    }

    function map(position){//マップ表示
        if(locationFlg == 1){//位置情報 有効/無効で分岐
            var mapLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
        }else{
            var mapLatLng = new google.maps.LatLng(33.58996835748549, 130.42080309563173);
        }
        var mapOptions = {//マップオプション
              zoom : 15,          // 拡大倍率
              center : mapLatLng,  // 緯度・経度
              disableDefaultUI: false,
              mapTypeControl: false,
              zoomControl: true,
              streetViewControl: false,
              scrollwheel: true
        };
        map = new google.maps.Map(
              document.getElementById("map"), // マップを表示する要素
              mapOptions         // マップオプション
            );
        var marker = new google.maps.Marker({//マーカー表示
          map : map,             // 対象の地図オブジェクト
          position : mapLatLng   // 緯度・経度
        });
        google.maps.event.addListener(map, 'center_changed', function(){
          var location = map.getCenter();
          marker.setPosition(location);
        });
        
        dispLatLng();
        map.addListener('dragend', dispLatLng);
    }


    
    function initMap() {//位置情報 有効/無効で分岐
      // Geolocation APIに対応している
      if (navigator.geolocation) {
        // 現在地を取得
        navigator.geolocation.getCurrentPosition(
          // 位置情報 有効
          function(position) {
            locationFlg = 1;
            map(position);
          },
          // 位置情報 無効
          function(error) {
            // エラーメッセージを表示
            alert("位置情報の取得に失敗したため手動で指定してください。\nGPSを使用する場合は、設定を見直した後再読み込みしてください。");
            map();
          }
        );
        
      // Geolocation APIに対応していない
      } else {
        alert("この端末では位置情報が取得できません。\n手動で指定してください。");
        map();
      }
      
    }

    $('.form-check-input').change(function(){
        $('.g-map').toggle();
        if($(this).prop('checked')){
            initMap();
        }
    });


    // imageInputScript
    function readURL(input) {
        var id = $(input).attr("id");

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('label[for="' + id + '"] .upload-icon').css("border", "none");
                $('label[for="' + id + '"] .icon').hide();
                $('label[for="' + id + '"] .prev').attr('src', e.target.result).show();
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    function addImg(input){
        var id ,parent ,regex ,num;

        parent = document.querySelector('#'+$(input).attr("id")).parentElement;
        id = '#'+parent.id;
        num = Number([id.substr(13,1)]) +1;
        regex = id.substr(13,1);
        id = id.replace(regex,num)
        $(id).show();
    }

    $("input[id^='file-input']").change(function() {
        readURL(this);
        addImg(this);
    });


    $('.hide').hide();

